# Ground Litter V3.1 在线回放评估

## 结论

- 负样本视频中，在线状态机累计创建 17 个事件，只有 6 个通过 5 秒有效可见确认。
- 人工审核锚点映射结果为 TP=5、FP=1、FN=0；precision=83.3%、recall=100.0%、F1=90.9%。
- 5 个已审核垃圾位置全部保留；11 个非垃圾事件中 10 个被 context/actor/时序挡住，非垃圾暂缓率 90.9%。
- 唯一确认误报仍是 reviewed event `negative-v31-event-013` / track 186，适合作为后续 VLM 或固定设施规则的首个验证对象。
- T01 只形成一个主事件（ID [2]），72s 首见，81s 确认。墙钟延迟 9 秒包含遮挡暂停，确认只累计可见证据。
- clean holdout 共 20 帧，创建事件 0，确认事件 0。

## 漏斗

| 阶段 | 候选单位 | 真垃圾 | 非垃圾 | Precision |
|---|---:|---:|---:|---:|
| V3 人工审核 Track | 38 | 16 | 22 | 42.1% |
| 固定坐标事件合并 | 16 | 5 | 11 | 31.2% |
| 代表帧 Context + Actor | 6 | 5 | 1 | 83.3% |
| 在线 5 秒确认 | 6 | 5 | 1 | 83.3% |

## 确认事件与人工审核映射

| 在线事件 | 审核事件 | 标签 | 中心距离 px |
|---:|---|---|---:|
| 1 | negative-v31-event-001 | LITTER_CONFIRMED | 0.0 |
| 2 | negative-v31-event-002 | LITTER_CONFIRMED | 0.5 |
| 6 | negative-v31-event-009 | LITTER_CONFIRMED | 0.75 |
| 10 | negative-v31-event-010 | LITTER_CONFIRMED | 0.0 |
| 11 | negative-v31-event-011 | LITTER_CONFIRMED | 0.0 |
| 15 | negative-v31-event-013 | CLEAR_NON_LITTER | 0.0 |

## 环境与生命周期边界

- 本轮 `GLOBAL_LIGHT_CHANGE` 是“正在做明显光度补偿”的诊断状态，并不暂停判断；只有 `ENVIRONMENT_CHANGE` 才会暂停证据累计。负样本和正样本均完成候选确认，说明补偿没有抹掉目标。
- 素材没有“垃圾被清走后连续露出干净地面”的完整片段，因此 `CLEARED` 的 5 秒关闭条件只有单元测试覆盖，尚无真实视频验证。
- 当前 20px/30px 距离与 200px 外部变化面积仍是当前 1440p 视角的绝对像素参数。进入其他摄像头前，应改成基于地面透视分区和候选尺度的归一化参数。
- Clean Reference 在全部实验中只读，没有被当前帧、长期垃圾或遮挡更新。

## 是否可以进入多摄像头

当前摄像头已证明路线可行：Clean Reference 能补 YOLO 漏检，context/actor/时序可把 16 个审核事件压到 6 个确认事件，同时保留 5/5 个垃圾位置。进入其他摄像头前仍应补一段“投放—停留—清走”素材，验证真实 `CLEARED` 生命周期；随后冻结本摄像头参数作为基线，用 2–3 个相似视角做迁移验证，先只调整 ROI、透视尺度图和 Clean Profile，不逐摄像头重新调算法。
